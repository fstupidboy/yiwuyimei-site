---
title: "Sample Product A"
date: 2025-03-31T12:00:00
---

This is a sample product description in **Markdown** format.
